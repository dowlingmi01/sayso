var sayso = { baseDomain: 'app-demo.saysollc.com', version: '2.0.5' }; 
