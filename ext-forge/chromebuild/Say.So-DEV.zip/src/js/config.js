var sayso = { baseDomain: 'app-dev.saysollc.com', version: '2.0.4' }; 
