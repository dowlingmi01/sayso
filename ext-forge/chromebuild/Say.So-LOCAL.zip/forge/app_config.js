window.forge = {}; window.forge.config = {
    "author": "Say.So LLC", 
    "config_hash": "ef707b52acfd7601e87012b34dcdf11c0ebfe10e", 
    "config_version": "4", 
    "core": {
        "android": {
            "package_name": "io.trigger.forge4093d42274ec11e1a41a12313d1adcbe"
        }, 
        "firefox": {
            "package_name": "say.so"
        }, 
        "general": {
            "reload": false
        }, 
        "ie": {
            "package_name": "{12830336-3A64-4672-0FE0-9C18A0AFA2BD}"
        }, 
        "ios": {
            "package_name": "io.trigger.forge4093d42274ec11e1a41a12313d1adcbe"
        }, 
        "osx": {
            "package_name": "io.trigger.forge4093d42274ec11e1a41a12313d1adcbe"
        }, 
        "safari": {
            "package_name": "com.saysollc.app"
        }
    }, 
    "description": "A fun way to have your influence recognized, and your opinions rewarded!", 
    "homepage": "http://www.say.so/", 
    "json_safe_name": "Say.So", 
    "logging": {
        "level": "INFO"
    }, 
    "name": "Say.So", 
    "package_name": "sayso4093d42274ec11e1a41a12313d1adcbe", 
    "platform_version": "v1.4.44", 
    "plugins": {
        "activations": {
            "config": {
                "activations": [
                    {
                        "all_frames": true, 
                        "patterns": [
                            "http://*/*", 
                            "https://*/*"
                        ], 
                        "run_at": "start", 
                        "scripts": [
                            "src/js/config.js", 
                            "src/js/content.js"
                        ], 
                        "styles": []
                    }
                ]
            }, 
            "hash": "notahash"
        }, 
        "background": {
            "config": {
                "files": [
                    "js/config.js", 
                    "js/background.js"
                ]
            }, 
            "hash": "notahash"
        }, 
        "icons": {
            "config": {
                "chrome": {
                    "128": "img/icon128.png", 
                    "16": "img/icon16.png", 
                    "48": "img/icon48.png"
                }, 
                "firefox": {
                    "32": "img/icon32.png", 
                    "64": "img/icon64.png"
                }, 
                "safari": {
                    "32": "img/icon32.png", 
                    "48": "img/icon48.png", 
                    "64": "img/icon64.png"
                }
            }, 
            "hash": "notahash"
        }, 
        "notification": {
            "hash": "notahash"
        }, 
        "prefs": {
            "hash": "notahash"
        }, 
        "request": {
            "config": {
                "permissions": []
            }, 
            "hash": "notahash"
        }, 
        "tabs": {
            "hash": "notahash"
        }, 
        "update_url": {
            "config": {
                "firefox": "https://app.saysollc.com/xml/firefox-extension-updates.xml", 
                "safari": "http://app.saysollc.com/xml/safari-extension-updates.plist"
            }, 
            "hash": "notahash"
        }
    }, 
    "trigger_domain": "https://trigger.io", 
    "uuid": "4093d42274ec11e1a41a12313d1adcbe", 
    "version": "2.0.7", 
    "xml_safe_name": "Say.So"
};