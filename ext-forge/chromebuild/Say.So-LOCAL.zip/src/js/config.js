var sayso = { baseDomain: 'local.saysollc.com', version: '2.0.4' }; 
