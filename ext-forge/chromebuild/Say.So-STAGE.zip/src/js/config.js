var sayso = { baseDomain: 'app-staging.saysollc.com', version: '2.0.5' }; 
