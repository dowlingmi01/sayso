var sayso = { baseDomain: 'app-qa.saysollc.com', version: '2.0.3' }; 
