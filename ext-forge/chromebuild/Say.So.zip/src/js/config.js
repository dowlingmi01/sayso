var sayso = { baseDomain: 'app.saysollc.com', version: '2.0.5' }; 
